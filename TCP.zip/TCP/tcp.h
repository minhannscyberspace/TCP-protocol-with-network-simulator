#pragma once

#include <stdint.h>

void tcp_send(char*, size_t);
